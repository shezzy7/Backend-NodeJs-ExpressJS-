<?php
// Include WordPress core
define('WP_USE_THEMES', false); // Prevent theme loading
require_once('../wp-load.php'); // Adjust path if needed to locate wp-load.php from your custom folder

// Check if the user is logged in
if (!is_user_logged_in()) {
    wp_redirect('login.php'); // Redirect to login page if not logged in
    exit;
}

// Get the current logged-in user's information
$current_user = wp_get_current_user();
$user_id = $current_user->ID;

// Fetch tasks for the logged-in user
require_once "db_connection.php";
$conn = dbconn();
$sql = "SELECT * FROM task WHERE userid = $user_id";  // Fetch tasks for the logged-in user
$result = $conn->query($sql);

echo "<h1>Welcome, " . esc_html($current_user->display_name) . "!</h1>";
echo "<table>
    <tr>
        <th>Task ID</th>
        <th>Title</th>
        <th>Description</th>
        <th>Start Date</th>
        <th>End Date</th>
        <th>Delete</th>
        <th>Update</th>
    </tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>" . htmlspecialchars($row['taskid']) . "</td>
            <td>" . htmlspecialchars($row['title']) . "</td>
            <td>" . htmlspecialchars($row['discription']) . "</td>
            <td>" . htmlspecialchars($row['start_date']) . "</td>
            <td>" . htmlspecialchars($row['end_date']) . "</td>
            <td><a href='view.php?id=" . $row['taskid'] . "'>View</a></td>
            <td><a href='delete.php?id=" . $row['taskid'] . "'>Delete</a></td>
            <td><a href='update.php?id=" . $row['taskid'] . "'>Update</a></td>
        </tr>";
}

echo "</table>";
echo "<br><a href='input.php'>Add Task</a><br>";

// Logout link
echo '<a href="' . wp_logout_url('login.php') . '"><button>Logout</button></a>';
?>
