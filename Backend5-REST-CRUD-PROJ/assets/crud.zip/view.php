<?php
// Include database connection
require_once "db_connection.php";

// Get the task ID from the URL
$id = $_GET['id'];

// Create a connection to the database
$conn = dbconn();

// Query to get the task details by ID
$sql = "SELECT * FROM task WHERE taskid = $id";
$result = $conn->query($sql);

// Check if the task exists
if ($result->num_rows > 0) {
    // Fetch the task data
    $task = $result->fetch_assoc();
} else {
    echo "No task found.";
    exit;
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Task</title>
    <style>
        /* Shared Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .task-details {
            max-width: 600px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .task-details p {
            font-size: 18px;
            line-height: 1.6;
            margin: 10px 0;
        }

        .task-details label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .back-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Task Details</h1>

    <div class="task-details">
        <p><label>Title:</label> <?php echo htmlspecialchars($task['title']); ?></p>
        <p><label>Description:</label> <?php echo htmlspecialchars($task['discription']); ?></p>
        <p><label>Start Date:</label> <?php echo htmlspecialchars($task['start_date']); ?></p>
        <p><label>End Date:</label> <?php echo htmlspecialchars($task['end_date']); ?></p>

        <!-- Back Button to go to Home Page -->
        <a href="display.php" class="back-btn">Go Back to Home</a>
    </div>
</body>
</html>
