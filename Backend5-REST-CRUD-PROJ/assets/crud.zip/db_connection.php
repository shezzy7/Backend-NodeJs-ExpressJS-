<?php
    function dbconn(){
    $servername="localhost";
    $username="u821853410_hanzla";
    $password="Armin@11";
    $dbname="u821853410_todo";
      $connt=new mysqli($servername,$username,$password,$dbname);  //true false
      return $connt;
    }
?>