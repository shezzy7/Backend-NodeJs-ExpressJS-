<?php
// Include WordPress core
define('WP_USE_THEMES', false);
require_once('../wp-load.php');

if (!is_user_logged_in()) {
    wp_redirect('login.php'); // Redirect to login if not logged in
    exit;
}

$current_user = wp_get_current_user();
$user_id = $current_user->ID;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $discription = $_POST['discription'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    require_once "db_connection.php";
    $conn = dbconn();

    $sql = "INSERT INTO task (title, discription, start_date, end_date, userid) 
            VALUES ('$title', '$discription', '$start_date', '$end_date', '$user_id')";

    if ($conn->query($sql) === TRUE) {
        echo "Task added successfully!";
    } else {
        echo "Error adding task: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Task</title>
</head>
<body>
    <h1>Add a New Task</h1>
    <form action="input.php" method="post">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" required><br>
        <label for="discription">Description:</label>
        <input type="text" name="discription" id="discription" required><br>
        <label for="start_date">Start Date:</label>
        <input type="date" name="start_date" id="start_date" required><br>
        <label for="end_date">End Date:</label>
        <input type="date" name="end_date" id="end_date" required><br>
        <input type="submit" value="Add Task">
    </form>
</body>
</html>
