<?php
// Include WordPress core
define('WP_USE_THEMES', false);
require_once('../wp-load.php');

// Check if the user is logged in
if (!is_user_logged_in()) {
    wp_redirect('login.php'); // Redirect to login if not logged in
    exit;
}

$current_user = wp_get_current_user();
$user_id = $current_user->ID;

if (isset($_GET['id'])) {
    $task_id = $_GET['id'];

    // Fetch existing task data
    require_once "db_connection.php";
    $conn = dbconn();
    $sql = "SELECT * FROM task WHERE taskid = $task_id AND userid = $user_id";
    $result = $conn->query($sql);
    $task = $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $discription = $_POST['discription'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Update task in the database
    $sql = "UPDATE task SET title = '$title', discription = '$discription', start_date = '$start_date', end_date = '$end_date' WHERE taskid = $task_id";
    if ($conn->query($sql) === TRUE) {
        echo "Task updated successfully!";
        header("Location: read.php"); // Redirect back to task list
    } else {
        echo "Error: " . $conn->error;
    }
}

?>

<h1>Update Task</h1>
<form method="post" action="">
    <label for="title">Task Title:</label>
    <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($task['title']); ?>" required><br><br>

    <label for="description">Description:</label>
    <textarea id="discription" name="discription" required><?php echo htmlspecialchars($task['discription']); ?></textarea><br><br>

    <label for="start_date">Start Date:</label>
    <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($task['start_date']); ?>" required><br><br>

    <label for="end_date">End Date:</label>
    <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($task['end_date']); ?>" required><br><br>

    <input type="submit" value="Update Task" class="submit-btn">
</form>

<a href="read.php" class="back-btn">Back to Home</a>

<!-- Shared Styles -->
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 20px;
    }

    h1 {
        text-align: center;
        color: #333;
    }

    form {
        max-width: 500px;
        margin: 0 auto;
        background-color: white;
        padding: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }

    label {
        font-size: 18px;
        margin-bottom: 5px;
    }

    input[type="text"], textarea, input[type="date"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    .submit-btn {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        font-size: 16px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .submit-btn:hover {
        background-color: #45a049;
    }

    .back-btn {
        display: inline-block;
        margin-top: 20px;
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        text-decoration: none;
        border-radius: 5px;
    }

    .back-btn:hover {
        background-color: #45a049;
    }
</style>
