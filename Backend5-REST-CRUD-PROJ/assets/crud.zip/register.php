<?php
// Include WordPress core
define('WP_USE_THEMES', false);
require_once('../wp-load.php');

// Check if user is already logged in
if (is_user_logged_in()) {
    wp_redirect('display.php'); // Redirect to display page if logged in
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Create a new WordPress user
    $user_id = wp_create_user($username, $password, $email);

    if (is_wp_error($user_id)) {
        echo "<p>There was an error creating your account. Please try again.</p>";
    } else {
        // Log the user in automatically after registration
        $user = get_user_by('id', $user_id);
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
        wp_redirect('display.php'); // Redirect to display page after registration
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>
    <h1>Register</h1>
    <form action="register.php" method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required><br>
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required><br>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br>
        <input type="submit" value="Register">
    </form>

    <p>Already have an account? <a href="login.php">Login here</a></p>
</body>
</html>
