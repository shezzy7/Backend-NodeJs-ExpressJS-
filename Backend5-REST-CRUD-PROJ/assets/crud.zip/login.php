<?php
// Include WordPress core
define('WP_USE_THEMES', false); // Prevent theme loading
require_once('../wp-load.php'); // Adjust path if needed to locate wp-load.php from your custom folder

// Check if the user is already logged in
if (is_user_logged_in()) {
    wp_redirect('display.php'); // Redirect to the display page if already logged in
    exit;
}

// If form is submitted, try logging in the user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Use WordPress login system
    $user = wp_authenticate($username, $password);

    if (is_wp_error($user)) {
        echo "<p>Invalid login credentials. Please try again.</p>";
    } else {
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);
        wp_redirect('display.php'); // Redirect to display page after successful login
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <form action="login.php" method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required><br>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br>
        <input type="submit" value="Login">
    </form>

    <p>Don't have an account? <a href="register.php">Register here</a></p>
</body>
</html>
