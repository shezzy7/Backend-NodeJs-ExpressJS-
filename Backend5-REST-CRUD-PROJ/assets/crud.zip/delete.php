<?php
// Include WordPress core
define('WP_USE_THEMES', false);
require_once('../wp-load.php');

// Check if the user is logged in
if (!is_user_logged_in()) {
    wp_redirect('login.php'); // Redirect to login if not logged in
    exit;
}

$current_user = wp_get_current_user();
$user_id = $current_user->ID;

if (isset($_GET['id'])) {
    $task_id = $_GET['id'];

    require_once "db_connection.php"; // Include DB connection
    $conn = dbconn();

    // Delete task if it's owned by the logged-in user
    $sql = "DELETE FROM task WHERE taskid = $task_id AND userid = $user_id";
    if ($conn->query($sql) === TRUE) {
        echo "Task deleted successfully!";
        header('Location: read.php'); // Redirect to task list after deleting
        exit;
    } else {
        echo "Error deleting task: " . $conn->error;
    }
} else {
    echo "No task ID provided.";
}
?>
