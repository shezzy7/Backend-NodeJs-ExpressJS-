<?php
// Include WordPress core
define('WP_USE_THEMES', false);
require_once('../wp-load.php');

// Check if the user is logged in
if (!is_user_logged_in()) {
    wp_redirect('login.php'); // Redirect to login if not logged in
    exit;
}

$current_user = wp_get_current_user();
$user_id = $current_user->ID;

require_once "db_connection.php"; // Include DB connection
$conn = dbconn();

$sql = "SELECT * FROM task WHERE userid = $user_id"; // Fetch tasks for the logged-in user
$result = $conn->query($sql);

echo "<h1>Your Tasks</h1>";

echo "<table class='task-table'>
    <thead>
        <tr>
            <th>Task ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>View</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>" . htmlspecialchars($row['taskid']) . "</td>
            <td>" . htmlspecialchars($row['title']) . "</td>
            <td>" . htmlspecialchars($row['discription']) . "</td>
            <td>" . htmlspecialchars($row['start_date']) . "</td>
            <td>" . htmlspecialchars($row['end_date']) . "</td>
            <td><a href='view.php?id=" . $row['taskid'] . "' class='view-link'>View</a></td>
            <td><a href='update.php?id=" . $row['taskid'] . "' class='update-link'>Update</a></td>
            <td><a href='delete.php?id=" . $row['taskid'] . "' class='delete-link'>Delete</a></td>
        </tr>";
}

echo "</tbody></table>";
echo "<br><a href='add.php' class='add-task-btn'>Add New Task</a><br>";

// Logout link
echo '<a href="' . wp_logout_url('login.php') . '"><button class="logout-btn">Logout</button></a>';
?>

<!-- Shared Styles -->
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 20px;
    }

    h1 {
        text-align: center;
        color: #333;
    }

    .task-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .task-table thead {
        background-color: #4CAF50;
        color: white;
    }

    .task-table th, .task-table td {
        padding: 12px 15px;
        text-align: left;
        border: 1px solid #ddd;
    }

    .task-table tr:hover {
        background-color: #f2f2f2;
    }

    .view-link, .update-link, .delete-link {
        color: #4CAF50;
        text-decoration: none;
        padding: 5px 10px;
        border-radius: 5px;
        background-color: #e0e0e0;
        transition: background-color 0.3s;
    }

    .view-link:hover, .update-link:hover, .delete-link:hover {
        background-color: #4CAF50;
        color: white;
    }

    .add-task-btn, .logout-btn {
        display: inline-block;
        margin-top: 20px;
        padding: 10px 20px;
        color: white;
        background-color: #4CAF50;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
    }

    .add-task-btn:hover, .logout-btn:hover {
        background-color: #45a049;
    }

    .logout-btn {
        margin-top: 20px;
    }
</style>
