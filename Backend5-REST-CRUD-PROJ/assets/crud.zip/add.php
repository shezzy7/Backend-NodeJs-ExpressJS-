<?php
// Include WordPress core
define('WP_USE_THEMES', false);
require_once('../wp-load.php');

// Check if the user is logged in
if (!is_user_logged_in()) {
    wp_redirect('login.php'); // Redirect to login if not logged in
    exit;
}

$current_user = wp_get_current_user();
$user_id = $current_user->ID;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $discription = $_POST['discription'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Insert task into the database
    require_once "db_connection.php"; // Include DB connection
    $conn = dbconn();
    
    // Ensure the query matches the columns of your task table
    $sql = "INSERT INTO task (title, discription, start_date, end_date, userid) 
            VALUES ('$title', '$discription', '$start_date', '$end_date', $user_id)";
    
    if ($conn->query($sql) === TRUE) {
        echo "<p>New task added successfully!</p>";
    } else {
        echo "<p>Error: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Task</title>
    <!-- Shared Styles -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        label {
            font-size: 18px;
            margin-bottom: 5px;
        }

        input[type="text"], textarea, input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .submit-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #45a049;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .back-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Add New Task</h1>
    <form method="post" action="">
        <label for="title">Task Title:</label>
        <input type="text" id="title" name="title" required><br><br>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea><br><br>

        <label for="start_date">Start Date:</label>
        <input type="date" id="start_date" name="start_date" required><br><br>

        <label for="end_date">End Date:</label>
        <input type="date" id="end_date" name="end_date" required><br><br>

        <input type="submit" value="Add Task" class="submit-btn">
    </form>

    <a href="read.php" class="back-btn">Back to Home</a>
</body>
</html>
